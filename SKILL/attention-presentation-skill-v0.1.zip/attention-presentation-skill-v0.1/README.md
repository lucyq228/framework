# Attention Presentation Skill v0.1

Minimal test package for creating and revising presentation slides using attention-first communication principles.

The core behavior is contained in `SKILL.md`.

This version intentionally avoids extra reference files and rigid templates so the model has room to exercise judgment while following the core presentation principles.
