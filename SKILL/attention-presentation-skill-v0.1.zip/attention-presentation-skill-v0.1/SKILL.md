---
name: attention-presentation
description: Create or revise professional presentation slides for minimum time to meaning. Use for presentation storylines, slide headlines, layouts, charts, visual hierarchy, and slide messaging when the goal is clear, credible, memorable, decision-oriented communication.
version: 0.1
---

# Attention Presentation

## Goal

**Create presentations for minimum time to meaning.**

Make the message impossible to miss and the evidence effortless to understand.

Optimize for:

**Clarity → Credibility → Memorability → Action**

Do not optimize for information density, decoration, or visual complexity.

## Before creating slides

Determine:

- Who is the audience?
- What do they care about?
- What decision, question, or problem does the presentation address?
- What is the one overall takeaway?
- What evidence matters most?

Then build the storyline before designing individual slides.

## Storyline

Write short, conclusion-led slide headlines that tell the story when read in sequence.

Do not use generic topic titles when a meaningful conclusion is available.

Prefer:

> **Retention fell 12%**

instead of:

> Customer Retention Analysis

Prefer:

> **Paid social wins volume—but loses value**

instead of:

> Channel Performance

Keep headlines concise. Lead with the strongest outcome, number, recommendation, problem, or contrast.

## Every slide

Each slide should communicate **one dominant message**.

Use:

**Point → Proof → Meaning → Action**

Not every slide requires all four elements, but the audience should quickly understand:

- What matters?
- What proves it?
- Why does it matter?
- What happens next, if action is required?

Outcome comes before process.
Evidence comes before adjectives.
Concrete language comes before abstract language.

## Visual design

Use the simplest visual that proves the message.

Create a clear attention hierarchy:

1. Main message
2. Key evidence
3. Supporting context
4. Optional detail

Use whitespace, alignment, size, typography, position, and selective color to direct attention.

Highlight only what matters. Neutralize supporting information.

Color should communicate meaning or direct attention, not decorate.

Remove:

- unnecessary text
- repeated information
- excessive boxes
- chart clutter
- unnecessary colors
- decorative elements
- competing messages

Do not make the audience search for the insight. Highlight or annotate the evidence that supports the headline.

## Preserve flexibility

These are principles, not rigid templates.

Choose the layout, chart, visual structure, level of detail, and storytelling approach that best communicates the message.

Do not force every slide into the same format.

**Principles are strict. Execution is flexible.**

Break a rule when doing so clearly improves understanding, credibility, or communication.

Adapt the density to the use case:

- Live presentation: less text, stronger visuals, larger type, simpler focal point.
- Executive or leave-behind deck: enough context, annotation, and sourcing to stand alone.

## Accuracy and trust

Preserve the user's facts, numbers, intended meaning, and tone.

Do not invent evidence, metrics, findings, or business conclusions to make a slide more impressive.

If evidence is weak or incomplete, improve the communication without overstating the claim.

Distinguish actuals, forecasts, targets, scenarios, and assumptions clearly when relevant.

## Final check

Before accepting a slide, ask:

**3 seconds:** Is the main message obvious?

**10 seconds:** Is the proof and importance understandable?

**Headline:** Does it communicate a takeaway rather than merely a topic?

**Evidence:** Does the visual actually prove the headline?

**Hierarchy:** Is it obvious where to look first?

**Deletion:** Can anything be removed without weakening the message?

**So what?:** Is the implication clear?

**Credibility:** Are all claims supported?

If not, revise.

## Master principle

> **Make the message impossible to miss—and the evidence effortless to understand.**
